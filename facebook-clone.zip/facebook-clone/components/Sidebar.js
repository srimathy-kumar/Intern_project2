import Image from 'next/image'
import React from 'react'
import {ImUsers} from "react-icons/im";
import SidebarItems from "./SidebarItems";
import { MdGroups, MdOutlineOndemandVideo, MdOutlineExpandMore } from "react-icons/md";
import { AiOutlineShop } from "react-icons/ai";
import{BsStopwatch} from "react-icons/bs";
import { useSession } from 'next-auth/react';


const Sidebar = () => {
    const {data:session} = useSession(); 
    return (
        <div className="hidden lg:inline-flex flex-col py-2 pl-2 max-w-xl lg:min-w-[302px]">
            <div className="flex items-center space-x-2 py-3 pl-4 hover:bg-gray-200 rounded-l-xl cursor-pointer">
            <Image src={session?.user.image}
                alt="Picture of the author"
                className="rounded-full bg-gray-300"
                width={40}
                height={40}
            />
                  <p className="hidden sm:inline-flex font-medium">{session?.user.name}</p>
            </div>
            <SidebarItems Icon={ImUsers} value="Friends" />
            <SidebarItems Icon={MdGroups} value="Groups" />
            <SidebarItems Icon={AiOutlineShop} value="Marketplace" />
            <SidebarItems Icon={MdOutlineOndemandVideo} value="Watch Video" />
            <SidebarItems Icon={BsStopwatch} value="Memories" />
            <SidebarItems Icon={MdOutlineExpandMore} value="See More" />
        </div>
  )
}

export default Sidebar