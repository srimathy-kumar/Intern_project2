/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  
  images: {
    domains: ["cdn.pixabay.com", "static.xx.fbcdn.net", "platform-lookaside.fbsbx.com"],
  },
};

module.exports = nextConfig;
